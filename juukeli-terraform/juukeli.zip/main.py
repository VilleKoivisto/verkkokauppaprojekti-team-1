def juukeli(request):
	return "juukeli"